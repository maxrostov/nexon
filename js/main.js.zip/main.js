function hamburger_toggle() {
  $("#nav").toggle();
  $(".pda_menu").toggleClass("open");
}

function set_viewport(){
  var width_value = window.screen.width < 400 ? 'width=device-width' : 'width=1200';
  $('meta[name=viewport]').attr('content',width_value);
//мобильные адаптивно, а на планшетах будет зум

}

$(document).ready(function() {

  window.addEventListener('resize', function(){
    set_viewport();
  });
  set_viewport();

  $("#slider_partners").owlCarousel({
    autoplay: true,
    loop: true,
    margin: 10,
    responsiveClass: true,
    responsive: {
      0: {
        items: 1,
        nav: false
      },
      600: {
        items: 3,
        nav: false
      }
      ,
      1000: {
        items: 5,
        nav: false,
        loop: false,
        margin: 20
      }
    }
  });

  $("#slider_recommend").owlCarousel({
    autoplay: true,
    loop: true,
    margin: 10,
    responsiveClass: true,
    responsive: {
      0: {
        items: 1,
        nav: false
      },
      600: {
        items: 2,
        nav: false
      }
      ,
      1000: {
        items: 2,
        nav: false,
        loop: false,
        margin: 0
      }
    }
  });

  $("#slider_news").owlCarousel({
    autoplay: true,
    loop: true,
    margin: 10,
    responsiveClass: true,
    responsive: {
      0: {
        items: 1,
        nav: false
      },
      600: {
        items: 2,
        nav: false
      }
      ,
      1000: {
        items: 3,
        nav: false,
        loop: false,
        margin: 4
      }
    }
  });

});
